-- This script loads data into the tables needed for demos and
-- exercises in the Coursera Data Analyst specialization.

-- these are for the mydb database
USE mydb;
LOAD DATA LOCAL INFILE 'default/customers/customers.txt' INTO TABLE customers;
LOAD DATA LOCAL INFILE 'default/orders/orders.txt' INTO TABLE orders;
LOAD DATA LOCAL INFILE 'default/offices/offices.txt' INTO TABLE offices;
LOAD DATA LOCAL INFILE 'default/employees/employees.txt' INTO TABLE employees;
LOAD DATA LOCAL INFILE 'default/salary_grades/salary_grades.tsv' INTO TABLE salary_grades;


-- these are for the toy database
LOAD DATA LOCAL INFILE 'toy/makers/makers.tsv' INTO TABLE makers;
LOAD DATA LOCAL INFILE 'toy/toys/toys.txt' INTO TABLE toys;


-- these are for the fun database
LOAD DATA LOCAL INFILE 'fun/games/games.csv' INTO TABLE games FIELDS TERMINATED BY ',';
LOAD DATA LOCAL INFILE 'fun/inventory/data.txt' INTO TABLE inventory;
UPDATE inventory SET aisle = nullif(aisle, 0);
UPDATE inventory SET price = nullif(price, 0.0);
LOAD DATA LOCAL INFILE 'fun/card_rank/00000' INTO TABLE card_rank;
UPDATE card_rank SET value = nullif(value, 0);
LOAD DATA LOCAL INFILE 'fun/card_suit/00000' INTO TABLE card_suit FIELDS TERMINATED BY '';


-- these are for the wax database
LOAD DATA LOCAL INFILE 'wax/crayons/crayons.csv' INTO TABLE crayons FIELDS TERMINATED BY ',';
