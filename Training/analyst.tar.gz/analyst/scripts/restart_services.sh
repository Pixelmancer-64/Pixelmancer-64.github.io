#!/bin/bash 

# Script to restart services required for the Data Analyst course

handlePrematureTermination() {
  echo ""
  echo ""
  echo "WARNING: This script has been terminated before completion!"
  echo "Execute the command to run the script again."
  echo ""
  exit 1
}

trap handlePrematureTermination SIGINT SIGTERM

stop_service() {
  SERVICE=$1
  # Stops the service only if there is a corresponding init script,
  # allowing us to invoke on non-existent services, without error.
  if [ -e "/etc/init.d/$SERVICE" ]; then 
    # Stop the service
    sudo /sbin/service "$SERVICE" stop
  fi
}

start_service() {
  SERVICE=$1
  # Starts the service only if there is a corresponding init script,
  # allowing us to invoke on non-existent services, without error.
  if [ -e "/etc/init.d/$SERVICE" ]; then 
    # Avoid error by only starting service if it isn't already running
    sudo /sbin/service "$SERVICE" status > /dev/null
    if [  $? -ne 0 ]; then sudo /sbin/service "$SERVICE" start; fi
  else
    echo "* Warning: Service $SERVICE not installed"
  fi
}

# Stop services
echo ""
echo "Stopping services..."
echo ""

# Kill Spark executors
~/training_materials/analyst/scripts/shut_down_spark.sh QUIET

stop_service hue
stop_service impala-server
stop_service impala-catalog
stop_service impala-state-store
stop_service hive-server2
stop_service hive-metastore
stop_service mysqld
stop_service spark-history-server
stop_service hadoop-mapreduce-historyserver
stop_service hadoop-hdfs-namenode
stop_service hadoop-hdfs-datanode
stop_service hadoop-yarn-nodemanager
stop_service hadoop-yarn-resourcemanager
stop_service zookeeper-server

sleep 10

# Start services
echo ""
echo "Starting services..."
echo ""

start_service zookeeper-server
start_service hadoop-yarn-resourcemanager
start_service hadoop-yarn-nodemanager
start_service hadoop-hdfs-datanode
start_service hadoop-hdfs-namenode
start_service hadoop-mapreduce-historyserver
start_service spark-history-server
start_service mysqld
start_service hive-metastore
start_service hive-server2
start_service impala-state-store
start_service impala-catalog
start_service impala-server
start_service hue

sleep 20

echo ""
echo "All required services have been restarted."
echo ""
