-- This script creates tables needed for demos and
-- exercises in the Coursera Data Analyst 
-- specialization.

-- these are for the default database
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS offices;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS salary_grades;

CREATE TABLE customers 
   (cust_id CHAR(2),
    name VARCHAR(20),
    country CHAR(2));

CREATE TABLE orders 
   (order_id INT,
    cust_id CHAR(2),
    empl_id INT,
    total NUMERIC(5,2));

CREATE TABLE offices
   (office_id CHAR(2),
    city VARCHAR(20),
    state_province VARCHAR(20),
    country CHAR(2));

CREATE TABLE employees
   (empl_id INT,
    first_name VARCHAR(15),
    last_name VARCHAR(20),
    salary INT,
    office_id CHAR(2));

CREATE TABLE salary_grades
   (grade SMALLINT,
    min_salary INT,
    max_salary INT);

-- these are for the fun database
DROP TABLE IF EXISTS games;
DROP TABLE IF EXISTS inventory;
DROP TABLE IF EXISTS card_rank;
DROP TABLE IF EXISTS card_suit;

CREATE TABLE games
   (id INT,
    name VARCHAR(15),
    inventor VARCHAR(30),
    year CHAR(4),
    min_age SMALLINT,
    min_players SMALLINT,
    max_players SMALLINT,
    list_price NUMERIC(5,2));

CREATE TABLE inventory
   (shop VARCHAR(15),
   game VARCHAR(15),
   qty INT,
   aisle SMALLINT,
   price NUMERIC(5,2));

CREATE TABLE card_rank
   (rank VARCHAR(5),
   value SMALLINT);

CREATE TABLE card_suit
   (suit VARCHAR(8),
   color VARCHAR(5));

-- these are for the toy database
DROP TABLE IF EXISTS toys;
DROP TABLE IF EXISTS makers;

CREATE TABLE toys
   (id INT,
    name VARCHAR(20),
    price NUMERIC(5,2),
    maker_id INT);

CREATE TABLE makers
   (id INT,
   name VARCHAR(20),
   city VARCHAR(30));

-- these are for the wax database
DROP TABLE IF EXISTS crayons;

CREATE TABLE crayons
   (color VARCHAR(25),
    hex CHAR(6),
    red SMALLINT,
    green SMALLINT,
    blue SMALLINT,
    pack SMALLINT);
