#!/bin/bash

# This script will advance the state of the VM as if the
# exercise specified on the command line (and all those 
# before it) had been completed. For example, invoking 
# this script as:
#
#   $ advance_labs.sh lab4
#
# Will prepare you to begin work on exercise 5, meaning 
# that the state of the VM will be exactly the same as if 
# exercise 4 (as well as exercises 3, 2, and 1) had been
# manually completed.
#
# BEWARE: In all invocations, this script will first run
#         a 'cleanup' step which removes data in HDFS and
#         the local filesystem in order to simulate the
#         original state of the VM. 
#

ADIR=/home/training/training_materials/analyst

# ensure we run any scripts from a writable local directory, 
# which needs to also not conflict with anything
RUNDIR=/tmp/adht/labscripts/$RANDOM$$
mkdir -p $RUNDIR
cd $RUNDIR


cleanup() {
    echo "Cleaning up your system"

    # sudo -u hdfs hdfs dfs -rm -skipTrash -r -f 

    # Instead of executing each command in a separate Hive/Impala
    # session, it's much faster to run them all in one.

    # Note that the customers, order_details, orders, and
    # products tables are dropped and recreated here, in case the
    # student has altered or dropped them, even though those
    # tables are not created in the exercises.
    
# Need to drop tables from Hive/Impala databases (default, fly, fun, toy, wax)
# Recreate using the create_tables.hql script

TMP_SQL=tmp.sql
cat << __END_OF_SQL__ > $TMP_SQL

USE default;

__END_OF_SQL__

    cat $ADIR/scripts/create_tables.hql >> $TMP_SQL

    beeline -u jdbc:hive2://localhost:10000 --silent=true -f $TMP_SQL >/dev/null 2>&1
    rm $TMP_SQL

# Need to drop tables from MySQL database (mydb)
# Recreate using the create_tables_mysql.sql script 
# Load data using load_tables_mysql.sql script

# Need to drop tables from PostgreSQL database (pgdb, fun, toy, wax)
# Recreate using the scripts, one per db create_tables_postgres_pgdb.sql etc
# Load data using the scripts, one per db, load_tables_...

}
