-- This script loads data into the tables needed for demos and
-- exercises in the Coursera Data Analyst specialization.

-- these are for the pgdb database
COPY customers FROM '/home/training/training_materials/analyst/scripts/static_data/default/customers/customers.txt';
COPY orders FROM '/home/training/training_materials/analyst/scripts/static_data/default/orders/orders.txt';
COPY offices FROM '/home/training/training_materials/analyst/scripts/static_data/default/offices/offices.txt';
COPY employees FROM '/home/training/training_materials/analyst/scripts/static_data/default/employees/employees.txt';
COPY salary_grades FROM '/home/training/training_materials/analyst/scripts/static_data/default/salary_grades/salary_grades.tsv';

-- these are for the fun database

COPY games FROM '/home/training/training_materials/analyst/scripts/static_data/fun/games/games.csv' CSV;
COPY inventory FROM '/home/training/training_materials/analyst/scripts/static_data/fun/inventory/data.txt' WITH NULL AS '';
COPY card_rank FROM '/home/training/training_materials/analyst/scripts/static_data/fun/card_rank/00000' WITH NULL AS '';
COPY card_suit FROM '/home/training/training_materials/analyst/scripts/static_data/fun/card_suit/00000' DELIMITER '';

-- these are for the toy database
COPY makers FROM '/home/training/training_materials/analyst/scripts/static_data/toy/makers/makers.tsv';
COPY toys FROM '/home/training/training_materials/analyst/scripts/static_data/toy/toys/toys.txt';

-- this is for the wax database
COPY crayons FROM '/home/training/training_materials/analyst/scripts/static_data/wax/crayons/crayons.csv' CSV;