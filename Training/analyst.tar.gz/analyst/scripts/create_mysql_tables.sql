-- This script creates tables needed for demos and
-- exercises in the Coursera Data Analyst 
-- specialization.

-- pull all in the mydb database
DROP TABLE IF EXISTS mydb.customers;
DROP TABLE IF EXISTS mydb.orders;
DROP TABLE IF EXISTS mydb.offices;
DROP TABLE IF EXISTS mydb.employees;
DROP TABLE IF EXISTS mydb.salary_grades;
DROP TABLE IF EXISTS mydb.games;
DROP TABLE IF EXISTS mydb.inventory;
DROP TABLE IF EXISTS mydb.card_rank;
DROP TABLE IF EXISTS mydb.card_suit;
DROP TABLE IF EXISTS mydb.toys;
DROP TABLE IF EXISTS mydb.makers;
DROP TABLE IF EXISTS mydb.crayons;
DROP DATABASE IF EXISTS mydb;

CREATE DATABASE mydb;
USE mydb;

CREATE TABLE customers 
   (cust_id CHAR(2),
    name VARCHAR(20),
    country CHAR(2));

CREATE TABLE orders 
   (order_id INT(3),
    cust_id CHAR(2),
    empl_id INT(3),
    total DECIMAL(5,2));

CREATE TABLE offices
   (office_id CHAR(2),
    city VARCHAR(20),
    state_province VARCHAR(20),
    country CHAR(2));

CREATE TABLE employees
   (empl_id INT(3),
    first_name VARCHAR(15),
    last_name VARCHAR(20),
    salary INT(6),
    office_id CHAR(2));

CREATE TABLE salary_grades
   (grade TINYINT(1),
    min_salary INT(6),
    max_salary INT(7));

CREATE TABLE toys
   (id INT(3),
    name VARCHAR(20),
    price DECIMAL(5,2),
    maker_id INT(4));

CREATE TABLE makers
   (id INT(4),
   name VARCHAR(20),
   city VARCHAR(30));

CREATE TABLE games
   (id INT(2),
    name VARCHAR(15),
    inventor VARCHAR(30),
    year CHAR(4),
    min_age TINYINT(2),
    min_players TINYINT(2),
    max_players TINYINT(2),
    list_price DECIMAL(5,2));

CREATE TABLE inventory
   (shop VARCHAR(15),
   game VARCHAR(15),
   qty INT(3),
   aisle TINYINT(2),
   price DECIMAL(5,2));

CREATE TABLE card_rank
   (rank VARCHAR(5),
   value TINYINT(2));

CREATE TABLE card_suit
   (suit VARCHAR(7),
   color VARCHAR(5));

CREATE TABLE crayons
   (color VARCHAR(25),
    hex CHAR(6),
    red SMALLINT(3),
    green SMALLINT(3),
    blue SMALLINT(3),
    pack TINYINT(2));
